<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '' );

/** MySQL database username */
define( 'DB_USER', '' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', '' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'jnPAkC0BhF~`5ER.PX|+5jDka3r9my4` dxI0IHzrex>N;y$;8J7k-OOQ27F$^l&' );
define( 'SECURE_AUTH_KEY',   'zIr}wI7o|g&<on8r:HT78,{#o?!sftxsw,LGgxCh@b]7zKLQ,+F.Go$n7^zzO+Wz' );
define( 'LOGGED_IN_KEY',     'uATthV+zwHxiXL[;R!*K9B^~y7q+/C19*>Wil3!w{+>x?yLGXf|1L,0X=OPV=mtx' );
define( 'NONCE_KEY',         '/VCS%ZiP97]2YW@W<Od/C,&W GRPBr&2o4Q]2IwUSbE?&}G.[9;9,j6Q(#}=:;+N' );
define( 'AUTH_SALT',         'SpHV0tZ?=?}%?L}8wzT,|O6wBVYpiJ,w>Le>WQl{Q>M?cV7-w!Ynf{,n[rg$+/r!' );
define( 'SECURE_AUTH_SALT',  'dV5JVC4b1lx`3eR&6l::Chn4{,(DK4W;1hi$yXc+!wh{}fXAcam/%j]z1C8q?}:s' );
define( 'LOGGED_IN_SALT',    '`yp%[4/-i[3n;5kP./hfhb<`ZQPlQhT>=yO0O.WW6N(_v@F9p=PRdmx=NpcAGIUV' );
define( 'NONCE_SALT',        '}rsEScB~M_HC@@,RMxWz0`9%]*(#tg;tT_U %S-q^:Bx+<8#?:EyE|TZXi|,ToT3' );
define( 'WP_CACHE_KEY_SALT', '?`)oe65&Z|NEZQ{H wrl~f[yN%Dl8A$KoS5E&ELvkIDU^=q,,bVUk,:MEW#H+SzZ' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
@include_once('/var/lib/sec/wp-settings.php'); // Added by SiteGround WordPress management system
